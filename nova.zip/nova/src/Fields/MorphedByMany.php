<?php

namespace Laravel\Nova\Fields;

class MorphedByMany extends MorphToMany
{
    //
}
