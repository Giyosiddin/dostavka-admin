<?php

namespace Laravel\Nova\Fields;

use Laravel\Nova\Contracts\Cover;

class Avatar extends Image implements Cover
{
    //
}
